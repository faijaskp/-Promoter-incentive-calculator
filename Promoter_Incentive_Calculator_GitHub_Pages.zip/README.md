# Promoter Incentive Calculator

A standalone, browser-based promoter incentive calculator covering the September 2026 source schemes.

## GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish the site.

The calculator runs entirely in the browser and does not require a server or database.

## Important

Review the incentive rates and business rules before publishing publicly, especially if the calculator contains internal/company-sensitive commercial information.
